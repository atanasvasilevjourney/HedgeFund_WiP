import vectorbt as vbt
import pandas as pd
import talib
from strategies.base_strategy import BaseStrategy

class TEMAStrategy(BaseStrategy):
    def __init__(self):
        super().__init__("TEMA")

    def validate_parameters(self, params: dict) -> bool:

        p1 = int(params['w1']) # Fast
        p2 = int(params['w2']) # Medium
        p3 = int(params['w3']) # Slow
        
        MIN_GAP_FAST = 10 

        if p1 >= p2:
            return False
        
        if not (p2 > p1 + MIN_GAP_FAST):
            return False

        if p3 == p1 or p3 == p2:
            return False

        return True

    def generate_signals(self, df: pd.DataFrame, params: dict) -> pd.DataFrame:

        w1 = int(params['w1'])
        w2 = int(params['w2'])
        w3 = int(params['w3'])
        
        close_np = df['Close'].values

        # Calculations
        t1 = pd.Series(talib.TEMA(close_np, timeperiod=w1), index=df.index)
        t2 = pd.Series(talib.TEMA(close_np, timeperiod=w2), index=df.index)
        t3 = pd.Series(talib.TEMA(close_np, timeperiod=w3), index=df.index)

        # Signal logic
        # Entry: bullish crossover
        entries = (
            t1.vbt.crossed_above(t2) |
            t1.vbt.crossed_above(t3) |
            t2.vbt.crossed_above(t3)
        )
        
        # Exit: bearish crossover
        exits = (
            t1.vbt.crossed_below(t2) |
            t1.vbt.crossed_below(t3) |
            t2.vbt.crossed_below(t3)
        )

        # Packaging results
        result = pd.DataFrame(index=df.index)
        result['entries'] = entries
        result['exits'] = exits
        
        return result