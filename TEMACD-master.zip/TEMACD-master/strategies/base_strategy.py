from abc import ABC, abstractmethod
import pandas as pd
import json
import numpy as np
from pathlib import Path

class BaseStrategy(ABC):
    def __init__(self, name):
        self.name = name

    @abstractmethod
    def generate_signals(self, df: pd.DataFrame, params: dict) -> pd.DataFrame:
        pass

    def validate_parameters(self, params: dict) -> bool:
        return True

    def save_best_params(self, params: dict, output_dir: Path):
        """
        Saves best parameters to JSON in the specific output directory.
        """
        filename = f"best_params_{self.name.lower()}.json"
        filepath = output_dir / filename

        # Convert Numpy types to Python native
        clean_params = {}
        for k, v in params.items():
            if isinstance(v, (np.integer, np.int64, np.int32)):
                clean_params[k] = int(v)
            elif isinstance(v, (np.floating, np.float64, np.float32)):
                clean_params[k] = float(v)
            else:
                clean_params[k] = v

        try:
            with open(filepath, "w") as f:
                json.dump(clean_params, f, indent=4)
            print(f" {self.name} Saved params to: {filepath}")
            return filepath  # Return path so we can use it later
        except Exception as e:
            print(f"❌ Error saving JSON for {self.name}: {e}")
            return None

    def load_params_from_path(self, filepath: Path):
        """
        Loads parameters from a specific path.
        """
        if not filepath.exists():
            raise FileNotFoundError(f"❌ File missing: {filepath}")
        
        with open(filepath, "r") as f:
            return json.load(f)