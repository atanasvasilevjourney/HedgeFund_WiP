import pandas as pd
from strategies.base_strategy import BaseStrategy
from strategies.macd_strategy import MACDStrategy
from strategies.tema_strategy import TEMAStrategy
from pathlib import Path

class TEMACDEnsemble(BaseStrategy):
    def __init__(self):
        super().__init__("Ensemble")
        self.macd_strat = MACDStrategy()
        self.tema_strat = TEMAStrategy()

    def generate_signals(self, df: pd.DataFrame, macd_json_path: Path = None, tema_json_path: Path = None) -> pd.DataFrame:
        """
        Generates combined signals. Requires paths to JSON config files.
        """
        
        # Load Parameters from specific paths
        if not macd_json_path or not macd_json_path.exists():
             raise FileNotFoundError(f"❌ Ensemble needs valid MACD JSON path. Got: {macd_json_path}")
        
        if not tema_json_path or not tema_json_path.exists():
             raise FileNotFoundError(f"❌ Ensemble needs valid TEMA JSON path. Got: {tema_json_path}")

        macd_params = self.macd_strat.load_params_from_path(macd_json_path)
        tema_params = self.tema_strat.load_params_from_path(tema_json_path)

        # Generate Component Signals
        macd_signals = self.macd_strat.generate_signals(df, macd_params)
        tema_signals = self.tema_strat.generate_signals(df, tema_params)

        # Combine Logic
        ent_macd = macd_signals['entries']
        ext_macd = macd_signals['exits']
        ent_tema = tema_signals['entries']
        ext_tema = tema_signals['exits']

        # ENTRY
        final_entries = ent_tema | ent_macd
        
        # EXIT
        final_exits = ext_tema | ext_macd
        
        return pd.DataFrame({'entries': final_entries, 'exits': final_exits})