import vectorbt as vbt
import pandas as pd
import numpy as np
import talib
from strategies.base_strategy import BaseStrategy

class MACDStrategy(BaseStrategy):
    def __init__(self):
        super().__init__("MACD")

    def generate_signals(self, df: pd.DataFrame, params: dict) -> pd.DataFrame:
        fast = int(params['fast'])
        slow = int(params['slow'])
        sig = int(params['signal'])
        
        # Calculations
        macd, signal, _ = talib.MACD(
            df['Close'].values, 
            fastperiod=fast, 
            slowperiod=slow, 
            signalperiod=sig
        )

        # Conversion to pandas
        macd_series = pd.Series(macd, index=df.index)
        signal_series = pd.Series(signal, index=df.index)

        # Entry/Exit logic
        entries = macd_series.vbt.crossed_above(signal_series)
        exits = macd_series.vbt.crossed_below(signal_series)

        # Packaging results
        result = pd.DataFrame(index=df.index)
        result['entries'] = entries
        result['exits'] = exits
        
        return result