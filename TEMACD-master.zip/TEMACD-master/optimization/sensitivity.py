import vectorbt as vbt
import pandas as pd
import numpy as np

def run_sensitivity_analysis(data, signal_func, base_params, param_names, train_ratio=0.6, ranges=10):
    """
    Sensitivity analysis.
    """
    print(f"\n RUNNING SENSITIVITY ANALYSIS (Range +/- {ranges})")
    
    # Data split
    split_idx = int(len(data) * train_ratio)
    data_is = data.iloc[:split_idx]
    data_oos = data.iloc[split_idx:]
    
    # Base results
    ent_is, ext_is = signal_func(data_is, base_params)
    base_sharpe_is = vbt.Portfolio.from_signals(data_is, ent_is, ext_is, freq='1d', fees=0.001).sharpe_ratio()
    
    ent_oos, ext_oos = signal_func(data_oos, base_params)
    base_sharpe_oos = vbt.Portfolio.from_signals(data_oos, ent_oos, ext_oos, freq='1d', fees=0.001).sharpe_ratio()

    results = []

    for i, p_name in enumerate(param_names):
        current_val = int(base_params[i])
        # Examine the parameter enviroment
        test_values = range(max(2, current_val - ranges), current_val + ranges + 1)
        
        for val in test_values:
            if val == current_val: continue
            
            # Creating a new parameter string
            new_params = list(base_params)
            new_params[i] = val
            new_params = tuple(new_params)
            
            try:
                # IS Test
                ent, ext = signal_func(data_is, new_params)
                pf = vbt.Portfolio.from_signals(data_is, ent, ext, freq='1d', fees=0.001)
                sharpe_is = pf.sharpe_ratio()
                
                # OOS Test
                ent, ext = signal_func(data_oos, new_params)
                pf = vbt.Portfolio.from_signals(data_oos, ent, ext, freq='1d', fees=0.001)
                sharpe_oos = pf.sharpe_ratio()
                
                # Delta %
                d_is = ((sharpe_is - base_sharpe_is) / abs(base_sharpe_is)) * 100 if base_sharpe_is != 0 else 0
                d_oos = ((sharpe_oos - base_sharpe_oos) / abs(base_sharpe_oos)) * 100 if base_sharpe_oos != 0 else 0
                
                results.append({
                    p_name: val,
                    'is_sharpe_delta': d_is,
                    'oos_sharpe_delta': d_oos,
                    **{pn: base_params[j] for j, pn in enumerate(param_names) if i != j}
                })
            except:
                continue
                
    return pd.DataFrame(results)