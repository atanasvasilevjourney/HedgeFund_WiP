import vectorbt as vbt
import pandas as pd

def validate_and_print_top_n(pf_is, param_combinations, oos_close, signal_func, strategy_name="STRATEGY", n=20):
    """
    It takes the top N results from the in-sample and checks them on the out-of-sample.
    """
    is_sharpe = pf_is.sharpe_ratio()
    top_indices = is_sharpe.nlargest(min(n, len(is_sharpe))).index
    
    print(f"\n TOP {len(top_indices)} Validation OOS ({strategy_name})")
    print(f"{'Rank':<4} | {'Params':<20} | {'IS Sharpe':<10} | {'OOS Sharpe':<10} | {'OOS Ret %':<10}")
    print("-" * 70)
    
    results = []
    
    for rank, idx in enumerate(top_indices, 1):
        params = param_combinations[idx]
        is_sh = pf_is[idx].sharpe_ratio()
        
        # Test OOS
        try:
            entries, exits = signal_func(oos_close, params)
            pf_oos = vbt.Portfolio.from_signals(oos_close, entries, exits, freq='1d', fees=0.001, slippage=0.001)
            
            oos_sh = pf_oos.sharpe_ratio()
            oos_ret = pf_oos.total_return()
            
            print(f"{rank:<4} | {str(params):<20} | {is_sh:<10.2f} | {oos_sh:<10.2f} | {oos_ret*100:<10.1f}%")
            
            results.append({'params': params, 'oos_sharpe': oos_sh})
        except:
            continue
            
    # Returns the best parameters according to OOS
    if results:
        best = sorted(results, key=lambda x: x['oos_sharpe'], reverse=True)[0]
        return best['params']
    return None