import numpy as np
import yaml
import itertools
import vectorbt as vbt
from tqdm import tqdm
import pandas as pd
import gc
from pathlib import Path

# Batch Size configuration
BATCH_SIZE = 7000 

def get_fees_config(config_path='config/strategy_config.yaml'):
    """
    A helper function that extracts fees and slippage from the configuration file.
    This allows the optimisation engine to know what the transaction costs are.
    """
    try:
        with open(config_path, 'r') as f:
            cfg = yaml.safe_load(f)
            # Pobieramy z sekcji SETTINGS, a jak nie ma to dajemy domyślne 0.001
            return cfg['SETTINGS'].get('fees', 0.001), cfg['SETTINGS'].get('slippage', 0.001)
    except Exception as e:
        print(f"⚠️ Unable to load costs from configu ({e}). Using default values.")
        return 0.001, 0.001

def parse_config_range(cfg):
    """Parses start/stop/step from config into numpy array."""
    if isinstance(cfg, dict) and 'start' in cfg and 'stop' in cfg:
        return np.arange(cfg['start'], cfg['stop'], cfg.get('step', 1))
    return cfg

def generate_param_grid(strategy_name, config_path='config/strategy_config.yaml'):
    """Generates a list of all parameter combinations from YAML."""
    with open(config_path, 'r') as file:
        full_config = yaml.safe_load(file)
    
    strat_config = full_config.get(strategy_name)
    if not strat_config:
        raise ValueError(f"❌ Error: Strategy '{strategy_name}' not found in {config_path}")
    
    keys = []
    values = []
    for key, val in strat_config.items():
        keys.append(key)
        values.append(parse_config_range(val))
    
    return [dict(zip(keys, v)) for v in itertools.product(*values)]

def run_grid_search(strategy_class, data_is: pd.DataFrame, param_grid: list, sim_start_date=None):
    """
    VECTORIZED (BATCH) GRID SEARCH ENGINE.
    """
    strategy = strategy_class()
    
    # We retrieve the costs from the Config file
    fees, slippage = get_fees_config()
    
    if sim_start_date is None:
        sim_start_date = data_is.index[0]
        
    if pd.Timestamp(sim_start_date).tz is not None:
        sim_start_date = pd.Timestamp(sim_start_date).tz_localize(None)

    total_combs = len(param_grid)
    print(f"\n GRID SEARCH Start for: {strategy.name}")
    print(f"Combinations: {total_combs} | Batch Size: {BATCH_SIZE}")
    print(f"Using Fees: {fees*100}% | Slippage: {slippage*100}%")

    best_sharpe = -np.inf
    best_params = None

    chunks = [param_grid[i:i + BATCH_SIZE] for i in range(0, total_combs, BATCH_SIZE)]

    for batch_idx, batch_params in enumerate(tqdm(chunks, desc="Processing Batches")):
        entries_list = []
        exits_list = []
        valid_params_in_batch = []

        for params in batch_params:
            if not strategy.validate_parameters(params):
                continue
            
            try:
                sigs = strategy.generate_signals(data_is, params)
                ent = sigs['entries'].shift(1).fillna(False)
                ext = sigs['exits'].shift(1).fillna(False)
                
                ent_trimmed = ent.loc[sim_start_date:]
                ext_trimmed = ext.loc[sim_start_date:]
                
                if ent_trimmed.empty: continue

                entries_list.append(ent_trimmed)
                exits_list.append(ext_trimmed)
                valid_params_in_batch.append(params)
                
            except Exception:
                continue
        
        if not entries_list:
            continue

        try:
            entries_df = pd.concat(entries_list, axis=1)
            exits_df = pd.concat(exits_list, axis=1)
            close_trimmed = data_is['Close'].loc[sim_start_date:]
            
            #  We use the collected costs in the simulation
            pf_batch = vbt.Portfolio.from_signals(
                close_trimmed, 
                entries_df, 
                exits_df, 
                freq='1d', 
                fees=fees,         
                slippage=slippage  
            )
            
            sharpe_ratios = pf_batch.sharpe_ratio()
            max_sharpe_val = sharpe_ratios.max()
            
            if max_sharpe_val > best_sharpe:
                best_sharpe = max_sharpe_val
                best_col_idx = np.argmax(sharpe_ratios.values)
                best_params = valid_params_in_batch[best_col_idx]
                

        except Exception as e:
            print(f"⚠️ Batch Error: {e}")
            continue
        
        del entries_df, exits_df, pf_batch
        gc.collect()

    if best_params is None:
        print("❌ No profitable strategy found.")
        return None

    # We only return the parameters, the rest will be calculated by main.py
    return best_params