import sys
import os
import yaml
import pandas as pd
import vectorbt as vbt
import warnings
from pathlib import Path

# MODULE IMPORTS
from core.data_fetcher import DataFetcher
from core.data_plotter import TradingPlotter
from core.data_reporting import print_detailed_report
from optimization.optimizer_engine import run_grid_search, generate_param_grid
from optimization.sensitivity import run_sensitivity_analysis

# REGISTRY IMPORT
from core.registry_manager import RegistryManager 

# STRATEGY IMPORTS
from strategies.macd_strategy import MACDStrategy
from strategies.tema_strategy import TEMAStrategy
from strategies.ensemble_strategy import TEMACDEnsemble

# Set project path
sys.path.append(os.getcwd())
warnings.filterwarnings("ignore")


# LOAD CONFIGURATION

def load_config(path='config/strategy_config.yaml'):
    if not os.path.exists(path): raise FileNotFoundError(f"❌ Missing config: {path}")
    with open(path, 'r') as f: full_cfg = yaml.safe_load(f)
    return full_cfg['SETTINGS']

CFG = load_config()
TICKER = CFG['ticker']
CATEGORY = CFG['category']
DOWNLOAD_START = CFG['download_start']
DOWNLOAD_END = CFG.get('end_date', None)
IS_TRADING_START = CFG['trading_start']
TRAIN_RATIO = CFG['train_ratio']
FEES = CFG.get('fees', 0.001) 
SLIPPAGE = CFG.get('slippage', 0.001)

def main():
    print("="*70)
    print(f"🚀 QUANT SYSTEM")
    print(f"🎯 Asset: {TICKER} | Category: {CATEGORY}")
    print("="*70)

    # SETUP
    project_root = Path(os.getcwd())
    asset_base_path = project_root / "assets" / CATEGORY / TICKER
    
    # REGISTRY INITIALISATION
    registry = RegistryManager("assets/results_registry.yaml")

    # DATA LOADING
    try:
        df_full = DataFetcher.fetch_data(TICKER, DOWNLOAD_START, DOWNLOAD_END)
        # Using split_data as per your setup
        df_is, df_oos_buffered, oos_split_date = DataFetcher.split_data(
            df_full, TRAIN_RATIO, buffer_days=365
        )
        print(f"    📅 OOS Split Date: {oos_split_date}")
    except Exception as e:
        print(f"❌ Data Error: {e}")
        return

    # Store paths to JSONs
    json_paths = {}

    # OPTIMIZATION (IN-SAMPLE)

    strategies_to_optimize = [MACDStrategy, TEMAStrategy]
    
    for StratClass in strategies_to_optimize:
        strat = StratClass()
        print(f"\n  [PHASE 1] Analyzing Strategy: {strat.name}")
        
        output_dir = asset_base_path / f"grid_search_{strat.name.lower()}"
        plotter = TradingPlotter(TICKER, CATEGORY, output_dir)

        try:
            param_grid = generate_param_grid(strat.name)
            
            # Optimize
            best_params = run_grid_search(StratClass, df_is, param_grid, sim_start_date=IS_TRADING_START)
            
            if not best_params: 
                print(f"⚠️ No params found for {strat.name}")
                continue

            # Save JSON (handled by main.py now)
            saved_path = strat.save_best_params(best_params, output_dir)
            json_paths[strat.name] = saved_path

            # FULL ANALYSIS FOR PLOTS (IS + OOS)
            print(f"  Generating complete chart suite for {strat.name}...")
            
            signals_full = strat.generate_signals(df_full, best_params)
            ent_full = signals_full['entries'].shift(1).fillna(False)
            ext_full = signals_full['exits'].shift(1).fillna(False)
            
            # Full period simulation (for charts)
            pf_full_strat = vbt.Portfolio.from_signals(
                df_full['Close'].loc[IS_TRADING_START:], 
                ent_full.loc[IS_TRADING_START:], 
                ext_full.loc[IS_TRADING_START:], 
                freq='1d', fees=FEES, slippage=SLIPPAGE
            )
            
            # Simulation only on OOS (for metrics)
            pf_oos = vbt.Portfolio.from_signals(
                df_full['Close'].loc[oos_split_date:], 
                ent_full.loc[oos_split_date:], 
                ext_full.loc[oos_split_date:], 
                freq='1d', fees=FEES, slippage=SLIPPAGE
            )
            
            # Saving results
            # We need to calculate Sharpe at Training (IS) to get the Stability Score.
            pf_is = vbt.Portfolio.from_signals(
                df_full['Close'].loc[IS_TRADING_START:oos_split_date],
                ent_full.loc[IS_TRADING_START:oos_split_date],
                ext_full.loc[IS_TRADING_START:oos_split_date],
                freq='1d', fees=FEES, slippage=SLIPPAGE
            )
            
            train_sharpe = pf_is.sharpe_ratio()
            test_sharpe = pf_oos.sharpe_ratio()
            
            reg_stats = {
                'train_sharpe': train_sharpe,
                'test_sharpe': test_sharpe,
                'stability_score': (test_sharpe / train_sharpe) if train_sharpe != 0 else 0,
                'test_return': pf_oos.total_return(),
                'test_drawdown': pf_oos.max_drawdown()
            }
            registry.save_run(TICKER, strat.name, best_params, reg_stats)

            # Reporting
            print_detailed_report(pf_oos, f"{strat.name} OOS RESULT")
            pf_oos.stats().to_csv(output_dir / f"stats_{strat.name.lower()}.csv")

            # Charts (we use pf_full_strat where history is needed, pf_oos where test results are needed)
            plotter.plot_split_equity_curves(pf_full_strat, oos_split_date, "Optimized_Split") 
            plotter.plot_equity_with_shading(pf_full_strat, "Advantage_Full")
            plotter.plot_full_sample_signals(pf_full_strat, "Signals_Full")
            plotter.plot_underwater_and_drawdown(pf_full_strat, "Drawdown_Full")
            plotter.plot_rolling_stats(pf_full_strat)
            plotter.plot_trade_distribution(pf_full_strat)
            
            try: plotter.plot_monthly_returns_heatmap(pf_full_strat)
            except: pass

            # Sensitivity Analysis
            base_vals = tuple(best_params.values())
            p_names = list(best_params.keys())
            def strategy_wrapper(data, p_vals_tuple):
                p_dict = dict(zip(p_names, p_vals_tuple))
                if isinstance(data, pd.Series): data = data.to_frame(name='Close')
                res = strat.generate_signals(data, p_dict)
                return res['entries'].shift(1).fillna(False), res['exits'].shift(1).fillna(False)

            df_sens = run_sensitivity_analysis(df_full['Close'], strategy_wrapper, base_vals, p_names)
            plotter.plot_sensitivity_bars(df_sens, p_names, base_vals)

        except Exception as e:
            print(f"⚠️ Error processing {strat.name}: {e}")
            import traceback; traceback.print_exc()
            continue

    # ENSEMBLE (OOS VALIDATION)
    print(f"\n  [PHASE 2] Running Ensemble")
    ens_dir = asset_base_path / "ensemble_results"
    ens_plotter = TradingPlotter(TICKER, CATEGORY, ens_dir)

    try:
        ensemble = TEMACDEnsemble()
        
        # Generate Full Signals
        signals_full = ensemble.generate_signals(
            df_full,
            macd_json_path=json_paths.get("MACD"),
            tema_json_path=json_paths.get("TEMA")
        )
        ent_full = signals_full['entries'].shift(1).fillna(False)
        ext_full = signals_full['exits'].shift(1).fillna(False)
        
        # Full Portfolio (for plotting)
        pf_full = vbt.Portfolio.from_signals(
            df_full['Close'].loc[IS_TRADING_START:], 
            ent_full.loc[IS_TRADING_START:], 
            ext_full.loc[IS_TRADING_START:], 
            freq='1d', fees=FEES, slippage=SLIPPAGE, init_cash=100000
        )

        # FIX OOS Portfolio (for metrics)
        pf_ens_oos = vbt.Portfolio.from_signals(
            df_full['Close'].loc[oos_split_date:], 
            ent_full.loc[oos_split_date:], 
            ext_full.loc[oos_split_date:], 
            freq='1d', fees=FEES, slippage=SLIPPAGE
        )
        
        # ENSEMBLE RECORD
        # We calculate IS for Ensemble to have a complete comparison.
        pf_ens_is = vbt.Portfolio.from_signals(
            df_full['Close'].loc[IS_TRADING_START:oos_split_date], 
            ent_full.loc[IS_TRADING_START:oos_split_date], 
            ext_full.loc[IS_TRADING_START:oos_split_date], 
            freq='1d', fees=FEES, slippage=SLIPPAGE
        )
        
        tr_sharpe = pf_ens_is.sharpe_ratio()
        te_sharpe = pf_ens_oos.sharpe_ratio()
        
        ens_stats = {
            'train_sharpe': tr_sharpe,
            'test_sharpe': te_sharpe,
            'stability_score': (te_sharpe / tr_sharpe) if tr_sharpe != 0 else 0,
            'test_return': pf_ens_oos.total_return(),
            'test_drawdown': pf_ens_oos.max_drawdown(),
            'note': 'Hybrid (MACD + TEMA)'
        }
        registry.save_run(TICKER, "Ensemble", {"components": ["MACD", "TEMA"]}, ens_stats)
        # ================================

        # Reports
        print_detailed_report(pf_ens_oos, "ENSEMBLE (OOS ONLY)")
        pf_ens_oos.stats().to_csv(ens_dir / "ensemble_stats_oos.csv")
        
        print_detailed_report(pf_full, "ENSEMBLE (FULL HISTORY)")
        pf_full.stats().to_csv(ens_dir / "ensemble_stats_full.csv")
        
        # ALL CHARTS FOR ENSEMBLE
        print("   [*] Generating ALL Full Sample Charts...")
        ens_plotter.plot_split_equity_curves(pf_full, oos_split_date, "Final_Split")
        ens_plotter.plot_equity_with_shading(pf_full, "Advantage")
        ens_plotter.plot_full_sample_signals(pf_full, "Signals")
        ens_plotter.plot_equity_comparison(pf_full, "Full_Sample")
        ens_plotter.plot_underwater_and_drawdown(pf_full, "Full_Sample")
        ens_plotter.plot_trade_distribution(pf_full)
        ens_plotter.plot_rolling_stats(pf_full)
        ens_plotter.plot_monthly_returns_heatmap(pf_full)
        
    except Exception as e:
        print(f"❌ Full Sample Error: {e}")
        import traceback; traceback.print_exc()

    print("\n✅ SYSTEM FINISHED. Check 'assets/results_registry.yaml' for stats.")

if __name__ == "__main__":
    main()