==============================================================================
📂 QUANT SYSTEM ARCHITECTURE & FILE MAP (ALGO3)
==============================================================================

ROOT/ (ALGO3)
│
├── 📁 assets/                      # [AUTO-GENERATED] RESULTS STORAGE
│   └── 📁 crypto/                  # Category Folder
│       └── 📁 BTC-USD/             # Ticker Folder
│           ├── 📁 grid_search_macd/    # MACD Results (Plots, Stats, JSON)
│           ├── 📁 grid_search_tema/    # TEMA Results (Plots, Stats, JSON)
│           └── 📁 ensemble_results/    # FINAL HYBRID Results (Full Sample)
│
├── 📁 config/                      # CONFIGURATION
│   └── strategy_config.yaml        # Search ranges for optimization (No coding needed)
│
├── 📁 core/                        # CORE ENGINE MODULES
│   ├── __init__.py
│   ├── data_fetcher.py             # YFinance download & Smart Buffer Splitting
│   ├── data_plotter.py             # Charting engine (Matplotlib/Seaborn)
│   ├── data_reporting.py           # Console stats generator (Sharpe, Sortino)
│
├── 📁 optimization/                # OPTIMIZATION LOGIC
│   ├── __init__.py
│   ├── optimizer_engine.py         # The Grid Search Engine (Warm-up aware)
│   ├── sensitivity.py              # Robustness testing logic
│   ├── validator.py                # Out-of-Sample validation logic
│
├── 📁 strategies/                  # STRATEGY LIBRARY
│   ├── __init__.py
│   ├── base_strategy.py            # Abstract Base Class (Blueprints)
│   ├── macd_strategy.py            # MACD Logic + Parameters Validation
│   ├── tema_strategy.py            # TEMA Logic (Hybrid/Aggressive)
│   └── ensemble_strategy.py        # Master Strategy (Combines MACD + TEMA)
│
├── main.py                         # 🚀 MAIN ENTRY POINT (Run this file only)
└── requirements.txt                # Python Dependencies


==============================================================================
🚀 EXECUTION WORKFLOW
==============================================================================

The system is fully automated. You do NOT need to run separate scripts.

1. Install Dependencies (First time only):
   $ pip install -r requirements.txt

2. Run the System:
   $ python main.py

   WHAT HAPPENS AUTOMATICALLY:
   A. Downloads data with WARM-UP BUFFER (e.g., starts 2017 to trade in 2018).
   B. Splits data into In-Sample (Training) and Out-of-Sample (Testing).
   C. Optimizes MACD on Training data (ignoring warm-up year) -> Validates OOS.
   D. Optimizes TEMA on Training data (ignoring warm-up year) -> Validates OOS.
   E. Runs ENSEMBLE (Hybrid) using best params found in C & D.
   F. Runs FULL SAMPLE ANALYSIS (Real history simulation with red split line).


======================================================================
📘 USER MANUAL
======================================================================

1. HOW TO CHANGE THE ASSET (e.g., BTC-USD -> NVDA)
----------------------------------------------------------------------
You only need to edit ONE file: 'main.py'.

   Open 'main.py' and change the constants at the top:
   
   TICKER = "NVDA"
   CATEGORY = "stocks"      # Options: crypto, stocks, forex, indices
   
   # IMPORTANT: DOWNLOAD_START must be ~1 year before IS_TRADING_START
   DOWNLOAD_START = "2019-01-01"    # Data for indicators warmup
   IS_TRADING_START = "2020-01-01"  # Actual trading start

   Save and run 'python main.py'.

======================================================================

2. HOW TO CHANGE OPTIMIZATION RANGES?
----------------------------------------------------------------------
To change the parameters tested (e.g., test EMA from 10 to 50 instead of 5 to 20).
Do NOT touch the Python code.

   Open 'config/strategy_config.yaml':

   MACD:
     fast:
       start: 10   <-- Change this
       stop: 50    <-- Change this
       step: 2

   The system will automatically generate a new grid based on this file.

======================================================================

3. HOW TO INTERPRET RESULTS?
----------------------------------------------------------------------
After the script finishes, go to the 'assets/CATEGORY/TICKER' folder.

   A. 'grid_search_macd' & 'grid_search_tema':
      - Individual performance of component strategies.
      
   B. 'ensemble_results' (THE HOLY GRAIL):
      - Look for file: '..._full_split_equity_Final_Split.png'
      - RED DOTTED LINE separates Training (Left) from Validation (Right).
      - If the line goes up AFTER the red line, the strategy is robust.

======================================================================