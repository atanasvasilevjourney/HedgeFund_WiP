import pandas as pd
import vectorbt as vbt
from core.metrics import MetricsEngine

def print_detailed_report(portfolio: vbt.Portfolio, title: str = "STRATEGY REPORT"):
    """
    Generating raport using MetricsEngine.
    """
    print("\n" + "="*60)
    print(f" {title.upper()}")
    print("="*60)

    try:
        m = MetricsEngine.compute(portfolio, freq='1d')
    except Exception as e:
        print(f"⚠️ Error calculating advanced metrics: {e}")
        print(portfolio.stats()) # Fallback to standard
        return

    # PROFITABILITY
    print(f"\n  PERFORMANCE")
    print(f"   Total Return:      {m['total_return']*100:>.2f}%")
    print(f"   Annualized (CAGR): {m['annualized_return']*100:>.2f}%")
    print(f"   Net Profit ($):    ${m['net_profit']:,.2f}")

    # RISK
    print(f"\n  RISK PROFILE")
    print(f"   Max Drawdown:      {m['max_drawdown']*100:>.2f}%")
    print(f"   Max DD ($):        ${m['max_drawdown_dollars']:,.2f}")
    print(f"   Ulcer Index:       {m['ulcer_index']*100:>.2f} (Stress Level)")

    # QUALITY
    print(f"\n💎 STRATEGY QUALITY")
    print(f"   Sharpe Ratio:      {m['sharpe_ratio']:.2f}")
    print(f"   Calmar Ratio:      {m['calmar_ratio']:.2f}")
    
    # SQN
    sqn = m['sqn']
    sqn_grade = "HOLY GRAIL" if sqn > 3.0 else ("EXCELLENT" if sqn > 2.0 else ("AVERAGE" if sqn > 1.6 else "POOR"))
    
    print(f"   SQN Score:         {sqn:.2f}  -> {sqn_grade}")

    # TRADE STATS
    print(f"\n TRADE STATISTICS")
    print(f"   Total Trades:      {m['total_trades']}")
    print(f"   Win Rate:          {m['win_rate']*100:.1f}%")
    print(f"   Profit Factor:     {m['profit_factor']:.2f}")
    print(f"   Avg Win/Loss:      {m['avg_win_loss_ratio']:.2f}x")
    print(f"   Streaks (W/L):     {m['max_win_streak']} wins / {m['max_lose_streak']} losses")

    print("\n" + "="*60 + "\n")