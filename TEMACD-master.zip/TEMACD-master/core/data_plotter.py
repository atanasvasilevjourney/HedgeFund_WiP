import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import numpy as np
from pathlib import Path
import vectorbt as vbt
import seaborn as sns

# Style
plt.style.use('ggplot')
sns.set_theme(style="darkgrid")

class TradingPlotter:
    def __init__(self, ticker, category, asset_dir):
        self.ticker = ticker
        self.category = category
        self.asset_dir = Path(asset_dir)
        # Automated folder creation
        self.asset_dir.mkdir(parents=True, exist_ok=True)

    def save_plot(self, filename, fig=None):
        """Saves the graph to a file and closes it to free up memory."""
        if fig is None:
            fig = plt.gcf()
            
        if not filename.endswith(".png"):
            filename += ".png"
            
        path = self.asset_dir / filename
        
        try:
            fig.savefig(path, bbox_inches='tight', dpi=150)
            print(f"   [Plot] Saved: {filename}")
        except Exception as e:
            print(f"   [!] Saving error {filename}: {e}")
        finally:
            plt.close(fig)
            plt.close('all')

    def plot_equity_comparison(self, pf, label_suffix=""):
        fig = plt.figure(figsize=(12, 6))
        strat_ret = pf.total_return()
        close = pf.close
        initial_capital = pf.init_cash
        
        # Benchmark (Buy & Hold)
        if isinstance(close, pd.DataFrame): close = close.iloc[:, 0]
        benchmark = (close / close.iloc[0]) * initial_capital
        bench_ret = (benchmark.iloc[-1] - initial_capital) / initial_capital
        
        plt.plot(benchmark.index, benchmark.values, label=f'Buy & Hold ({bench_ret:.2%})', color='black', alpha=0.6)
        
        # Strategy
        equity = pf.value()
        plt.plot(equity.index, equity.values, label=f'Strategy {label_suffix} ({strat_ret:.2%})', color='blue', linewidth=2.0)
        
        plt.title(f"{self.ticker} - Strategy vs Buy & Hold", fontweight='bold')
        plt.legend()
        self.save_plot(f"{self.ticker}_equity_comparison_{label_suffix}.png", fig)

    def plot_underwater_and_drawdown(self, pf, label_suffix=""):
        returns = pf.returns()
        eq = (1 + returns).cumprod()
        peak = eq.cummax()
        dd = (eq - peak) / peak
        
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), sharex=True, gridspec_kw={'height_ratios': [2, 1]})
        
        ax1.plot(eq.index, (eq - 1) * 100, color='black')
        ax1.fill_between(eq.index, (eq - 1) * 100, (peak - 1) * 100, color='red', alpha=0.15)
        ax1.set_title(f'{self.ticker} - Cumulative Returns', fontweight='bold')
        
        ax2.fill_between(dd.index, dd * 100, 0, color='red', alpha=0.7)
        ax2.set_title('Drawdown %')
        self.save_plot(f"{self.ticker}_drawdown_{label_suffix}.png", fig)

    def plot_trade_distribution(self, pf):
        trades = pf.trades
        if trades.count() > 0:
            fig = plt.figure(figsize=(10, 6))
            pnl = trades.pnl.values 
            n, bins, patches = plt.hist(pnl, bins=30, alpha=0.7, edgecolor='black')
            for c, p in zip(bins, patches):
                plt.setp(p, 'facecolor', 'green' if c >= 0 else 'red')
            plt.axvline(0, color='black', linestyle='--')
            plt.title(f"{self.ticker} - Trade PnL Distribution", fontweight='bold')
            self.save_plot(f"{self.ticker}_pnl_dist.png", fig)

    def plot_rolling_stats(self, pf, window=252):
        returns = pf.returns()
        if len(returns) > window:
            rolling_sharpe = returns.rolling(window=window).apply(
                lambda x: (x.mean() * 252) / (x.std() * np.sqrt(252)) if x.std() != 0 else np.nan, raw=False)
            
            fig = plt.figure(figsize=(12, 5))
            plt.plot(rolling_sharpe.index, rolling_sharpe.values, color='blue', label='Rolling Sharpe')
            plt.axhline(1.0, color='green', linestyle='--'); plt.axhline(0.0, color='red', linestyle='--')
            plt.title(f'{self.ticker} - Rolling Sharpe (window={window})', fontweight='bold')
            self.save_plot(f"{self.ticker}_rolling_sharpe.png", fig)

    def plot_equity_with_shading(self, pf, label_suffix=""):
        fig, ax = plt.subplots(figsize=(15, 8))
        strategy_equity = pf.value()
        close = pf.close
        if isinstance(close, pd.DataFrame): close = close.iloc[:, 0]
        
        buy_and_hold = (close / close.iloc[0]) * pf.init_cash
        
        ax.plot(strategy_equity.index, strategy_equity, label='Strategy', color='blue')
        ax.plot(buy_and_hold.index, buy_and_hold, label='Buy & Hold', color='black', linestyle='--', alpha=0.6)
        
        ax.fill_between(strategy_equity.index, strategy_equity, buy_and_hold, 
                        where=(strategy_equity >= buy_and_hold), color='green', alpha=0.1, label='Advantage')
        ax.fill_between(strategy_equity.index, strategy_equity, buy_and_hold, 
                        where=(strategy_equity < buy_and_hold), color='red', alpha=0.1, label='Disadvantage')
        
        ax.set_title(f'{self.ticker} - Advantage Visualization', fontweight='bold')
        ax.legend()
        self.save_plot(f"{self.ticker}_advantage_{label_suffix}.png", fig)

    def plot_full_sample_signals(self, pf, label_suffix=""):
        fig = plt.figure(figsize=(14, 7))
        close = pf.close
        if isinstance(close, pd.DataFrame): close = close.iloc[:, 0]
        
        plt.plot(close.index, close.values, label='Price', color='gray', alpha=0.5)
        
        try:
            recs = pf.orders.records_arr
            if len(recs) > 0:
                buy_idxs = recs['idx'][recs['side'] == 0]
                sell_idxs = recs['idx'][recs['side'] == 1]
                
                if len(buy_idxs) > 0:
                    plt.scatter(close.index[buy_idxs], close.values[buy_idxs], marker='^', color='green', s=100, label='Buy', zorder=10)
                if len(sell_idxs) > 0:
                    plt.scatter(close.index[sell_idxs], close.values[sell_idxs], marker='v', color='red', s=100, label='Sell', zorder=10)
        except Exception as e:
            print(f"⚠️ Plotting signals error: {e}")

        plt.title(f"{self.ticker} - Executed Trades", fontweight='bold')
        plt.legend()
        self.save_plot(f"{self.ticker}_signals_{label_suffix}.png", fig)

    def plot_monthly_returns_heatmap(self, pf):
        """Generating heatmap"""
        try:
            returns = pf.returns()
            # Grouping based on criterias
            monthly = returns.groupby([returns.index.year, returns.index.month]).apply(lambda x: (1 + x).prod() - 1)
            monthly_matrix = monthly.unstack()
            
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.heatmap(monthly_matrix * 100, annot=True, fmt=".1f", cmap="RdYlGn", center=0, cbar_kws={'label': 'Return %'}, ax=ax)
            ax.set_title(f"{self.ticker} - Monthly Returns %", fontweight='bold')
            ax.set_ylabel("Year"); ax.set_xlabel("Month")
            self.save_plot(f"{self.ticker}_monthly_heatmap.png", fig)
        except Exception as e:
            print(f"⚠️ Unable to generate heatmap: {e}")

    def plot_sensitivity_bars(self, df_sens, param_names, base_params):

        if df_sens.empty: return
        
        cols = len(param_names)
        fig, axes = plt.subplots(2, cols, figsize=(6 * cols, 10))
        fig.suptitle(f'{self.ticker} - Parameter Sensitivity (Robustness)', fontsize=16, fontweight='bold')
        
        if cols == 1: 
            axes = np.array([[axes[0]], [axes[1]]])
        elif axes.ndim == 1:
            axes = axes.reshape(2, -1)

        for i, param in enumerate(param_names):
            # Filtering data
            subset = df_sens.copy()
            for j, other in enumerate(param_names):
                if i != j: 
                    subset = subset[subset[other] == base_params[j]]
            
            # Adding winner as a based point
            base_val_int = int(base_params[i])
            current_vals = subset[param].astype(int).values
            
            if len(subset) > 0 and base_val_int not in current_vals:
                new_row = subset.iloc[0].to_dict() 
                new_row[param] = base_params[i] 
                new_row['is_sharpe_delta'] = 0.0
                if 'oos_sharpe_delta' in new_row: new_row['oos_sharpe_delta'] = 0.0
                subset = pd.concat([subset, pd.DataFrame([new_row])], ignore_index=True)

            if subset.empty: continue

            # Sorting data
            subset = subset.sort_values(by=param)
            x_labels = [str(int(float(x))) for x in subset[param].values]
            base_val_str = str(base_val_int)
            
            base_idx = -1
            if base_val_str in x_labels:
                base_idx = x_labels.index(base_val_str)

            # Helping function
            def draw_subplot(ax, values, title_suffix):
                # Coloring
                colors = ['red' if x < -5 else 'orange' if x < 0 else 'lightgreen' if x < 5 else 'darkgreen' for x in values]
                x_indices = np.arange(len(x_labels))
                
                bars = ax.bar(x_indices, values, color=colors, edgecolor='black', width=0.8)
                ax.axhline(0, color='black', linewidth=1)
                
                # Choosing winner
                if base_idx != -1 and base_idx < len(bars):
                    ax.axvline(base_idx, color='blue', linestyle='--', linewidth=2.5, alpha=0.5)
                    bars[base_idx].set_edgecolor('blue')
                    bars[base_idx].set_linewidth(2)
                
                total_bars = len(x_indices)
                if total_bars > 15:
                    step = max(1, total_bars // 8) 
                    ticks_to_show = list(range(0, total_bars, step))
                    if base_idx != -1 and base_idx not in ticks_to_show:
                        ticks_to_show.append(base_idx)
                    ticks_to_show.sort()
                    ax.set_xticks(ticks_to_show)
                    ax.set_xticklabels([x_labels[k] for k in ticks_to_show], rotation=0, fontsize=9)
                else:
                    ax.set_xticks(x_indices)
                    ax.set_xticklabels(x_labels, rotation=0, fontsize=9)

                ax.set_title(f'{param} ({title_suffix})', fontweight='bold', fontsize=11)
                ax.set_ylabel('Sharpe Δ %')
                ax.grid(axis='y', alpha=0.3)

            # Plotting IS (upper) and OOS (lower) chart for this paramter
            draw_subplot(axes[0, i], subset['is_sharpe_delta'], "In-Sample")
            if 'oos_sharpe_delta' in subset.columns:
                draw_subplot(axes[1, i], subset['oos_sharpe_delta'], "Out-of-Sample")

        plt.tight_layout()
        self.save_plot(f"{self.ticker}_sensitivity_analysis.png", fig)
    
    def plot_split_equity_curves(self, pf_full, split_date, label_suffix=""):
        """
        It draws a capital curve for the entire period, marking the IS/OOS division.
        """
        fig, ax = plt.subplots(figsize=(14, 7))
    
        equity = pf_full.value()
        
        # Equity line (blue)
        ax.plot(equity.index, equity.values, color='blue', label='Full Sample Equity', linewidth=1.5)
        
        # Ret dot line (split)
        try:
            ax.axvline(x=split_date, color='red', linestyle='--', linewidth=2, label='IS / OOS Split')
            
            ylim = ax.get_ylim()
            ax.fill_betweenx(ylim, split_date, equity.index[-1], color='orange', alpha=0.1, label='Out-of-Sample Zone')
        except Exception as e:
            print(f"⚠️ Problem with drawing dividing lines (check date format): {e}")

        ax.set_title(f"{self.ticker} - Full Sample Equity (Training vs Validation)", fontweight='bold')
        ax.legend(loc='upper left')
        ax.grid(True, alpha=0.3)
        
        self.save_plot(f"{self.ticker}_full_split_equity_{label_suffix}.png", fig)