import yfinance as yf
import pandas as pd
from datetime import timedelta

class DataFetcher:
    @staticmethod
    def fetch_data(ticker: str, start_date: str, end_date: str ) -> pd.DataFrame:
        print(f"[DataFetcher] Downloading data for: {ticker} (Start: {start_date})...")
        df = yf.download(ticker, start=start_date, end=end_date, progress=False)
        
        if df.empty:
            raise ValueError(f"❌ Puste dane dla {ticker}!")

        # Fix MultiIndex
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        # Fix No Close Column
        if 'Close' not in df.columns:
            if 'Adj Close' in df.columns:
                df['Close'] = df['Adj Close']
            else:
                raise ValueError("❌ No Close/Adj Close column.")

        df.dropna(inplace=True)
        return df

    @staticmethod
    def split_data(df: pd.DataFrame, train_ratio: float = 0.6, buffer_days: int = 365):
        """
        Splits data for IS i OOS parts.
        """
        split_idx = int(len(df) * train_ratio)
        
        # In-Sample
        data_is = df.iloc[:split_idx].copy()
        
        # Out-of-Sample
        start_oos_idx = max(0, split_idx - buffer_days)
        data_oos_buffered = df.iloc[start_oos_idx:].copy()
        
        oos_start_date = df.index[split_idx]
        
        print(f"[DataFetcher] Smart Split (Buffer = {buffer_days} days):")
        print(f"   🔹 IS Range:    {data_is.index[0].date()} -> {data_is.index[-1].date()}")
        print(f"   🔸 OOS Trading: {oos_start_date.date()} -> {data_oos_buffered.index[-1].date()}")
        
        return data_is, data_oos_buffered, oos_start_date