import numpy as np
import pandas as pd
import vectorbt as vbt
from typing import Dict, Any

class MetricsEngine:
    """
    Advanced metrics calculator matching Hedge Fund standards.
    Calculates SQN, Ulcer Index, Serenity Index, and Streak Analysis.
    """

    @staticmethod
    def compute(pf: vbt.Portfolio, freq: str = '1d') -> Dict[str, Any]:
        """
        Main entry point to calculate all pro metrics.
        """
        # 1. Base Metrics (VectorBT Standard)
        total_return = pf.total_return()
        ann_return = pf.annualized_return(freq=freq)
        max_dd = pf.max_drawdown()
        sharpe = pf.sharpe_ratio(freq=freq)
        calmar = pf.calmar_ratio(freq=freq)
        
        # 2. Trade Analysis
        trades = pf.trades
        n_trades = trades.count()
        
        # Win Rate & Profit Factor
        win_rate = trades.win_rate()
        profit_factor = trades.profit_factor()
        
        # 3. Advanced Custom Metrics
        sqn = MetricsEngine._calculate_sqn(trades)
        ulcer = MetricsEngine._calculate_ulcer_index(pf)
        serenity = MetricsEngine._calculate_serenity_index(ann_return, max_dd, ulcer)
        
        # FIX: Safe Streak Calculation
        try:
            ws = trades.winning_streak()
        except TypeError:
            ws = trades.winning_streak
            
        try:
            ls = trades.losing_streak()
        except TypeError:
            ls = trades.losing_streak

        win_streak = ws.max() if n_trades > 0 else 0
        lose_streak = ls.max() if n_trades > 0 else 0

        equity = pf.value()
        net_profit = equity.iloc[-1] - equity.iloc[0]
        max_dd_dollars = (pf.drawdown() * pf.value()).max()

        return {
            # Performance
            "total_return": total_return,
            "annualized_return": ann_return,
            "net_profit": net_profit,
            
            # Risk
            "max_drawdown": max_dd,
            "max_drawdown_dollars": max_dd_dollars,
            "ulcer_index": ulcer,
            
            # Quality Ratios
            "sharpe_ratio": sharpe,
            "calmar_ratio": calmar,
            "sqn": sqn,              
            "serenity_index": serenity,
            "profit_factor": profit_factor,
            
            # Trade Stats
            "total_trades": n_trades,
            "win_rate": win_rate,
            "avg_win_loss_ratio": MetricsEngine._calculate_payoff(trades),
            "max_win_streak": int(win_streak) if not np.isnan(win_streak) else 0,
            "max_lose_streak": int(lose_streak) if not np.isnan(lose_streak) else 0
        }

    @staticmethod
    def _calculate_sqn(trades) -> float:
        """
        System Quality Number (Van Tharp).
        Formula: SquareRoot(N) * (Expectancy / StdDev)
        """
        count = trades.count()
        if count < 2: return 0.0
        
        trade_rets = trades.returns
        
        avg_ret = trade_rets.mean()
        std_ret = trade_rets.std()
        
        if std_ret == 0: return 0.0
        
        return np.sqrt(count) * (avg_ret / std_ret)

    @staticmethod
    def _calculate_ulcer_index(pf) -> float:
        """
        Measures the depth and duration of drawdowns.
        """
        dd = pf.drawdown()
        return np.sqrt((dd ** 2).mean())

    @staticmethod
    def _calculate_serenity_index(ann_ret, max_dd, ulcer) -> float:
        """
        Advanced risk-adjusted return metric.
        """
        risk = abs(max_dd) * ulcer
        if risk == 0: return 0.0
        return ann_ret / risk

    @staticmethod
    def _calculate_payoff(trades) -> float:
        """Average Win / Average Loss"""
        try:
            rets = trades.returns
            wins = rets[rets > 0].mean()
            losses = abs(rets[rets < 0].mean())
            if losses == 0: return 0.0
            return wins / losses
        except:
            return 0.0