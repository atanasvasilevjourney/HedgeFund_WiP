import yaml
import os
from datetime import datetime
import numpy as np
from pathlib import Path

class RegistryManager:
    def __init__(self, filepath="assets/results_registry.yaml"):
        self.filepath = Path(filepath)
        self.filepath.parent.mkdir(parents=True, exist_ok=True)

    def _convert_numpy(self, obj):
        """
        Converts numpy types to native Python types (int, float) for YAML serialization.
        """
        if isinstance(obj, (np.integer, np.int64, np.int32)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64, np.float32)):
            return float(obj)
        elif isinstance(obj, dict):
            return {k: self._convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_numpy(i) for i in obj]
        return obj

    def load_registry(self):
        """Loads existing registry or returns empty dict if file doesn't exist."""
        if not self.filepath.exists():
            return {}
        try:
            with open(self.filepath, 'r') as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    def save_run(self, ticker, strategy_name, params, metrics):
        """
        Saves optimization results to YAML file.
        Updates/Overwrites entry for specific Ticker and Strategy.
        """
        registry = self.load_registry()

        # Initialize ticker structure if missing
        if ticker not in registry:
            registry[ticker] = {}
        
        # Clean numpy types
        clean_params = self._convert_numpy(params)
        clean_metrics = self._convert_numpy(metrics)

        # Create entry payload
        entry = {
            'strategy': strategy_name,
            'last_optimized': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'params': clean_params,
            # Unpack metrics (e.g. sharpe, return, stability_score)
            **clean_metrics
        }

        # Save under strategy key
        registry[ticker][strategy_name] = entry

        # Dump to file
        with open(self.filepath, 'w') as f:
            yaml.dump(registry, f, sort_keys=False, default_flow_style=False)
        
        print(f" [Registry] Entry updated in: {self.filepath}")